package com.example.flutter_appsahrebuttun

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
