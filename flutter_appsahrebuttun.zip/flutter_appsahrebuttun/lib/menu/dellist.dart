import 'package:flutter/material.dart';
class Dellist extends StatelessWidget{
  final marka;
  final screenSize;
  final storage ;
  final price;
  final RAM;
  Dellist({this.marka,this.price,this.RAM,this.screenSize,this.storage,});
  @override
  Widget build(BuildContext context) {
    return InkWell(child:
    Container(  height: 160,
      width: 100,
      child: Card(
        child: Row( children: <Widget>[
          Expanded(child: Image.asset('images/dell.jpg'),
          ),
          Expanded(flex :1, child: Container
            (alignment: Alignment.topRight,height: 200,
            child: Column(crossAxisAlignment:CrossAxisAlignment.start
            , children: <Widget>[
              Container (margin: EdgeInsets.only(top: 18,bottom: 18),
                child: Text('Özelliler',style: TextStyle(fontWeight: FontWeight.w800,color: Colors.blue),
                textAlign: TextAlign.center,),
              ),
              Row(children: <Widget>[
                Container(margin: EdgeInsets.only(top: 2,bottom: 2)
                  , child:Text( 'marka',  style: TextStyle(color:Colors.indigoAccent) ,
                  ),
                ),
                Container(margin: EdgeInsets.only(top: 2,bottom: 2) ,
                  child: Text( marka,style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w600,),),),],),
              Row(children: <Widget>[Text(' price:' ,  style: TextStyle(color:Colors.indigoAccent,) ,),
                Text(price,style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w600,),)
              ],),
              Row(children: <Widget>[Text('RAM ' ,  style: TextStyle(color:Colors.indigoAccent) ,),
                Text(RAM,style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w600,),)],),
              Row(children: <Widget>[Text('screenSize' ,  style: TextStyle(color:Colors.indigoAccent) ,),
                Text(screenSize,style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w600,),)],),
              Row(children: <Widget>[Text('storage:' ,  style: TextStyle(color:Colors.indigoAccent) ,),
                Text( storage,style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w600,)
                  ,)],),
            ],),),),]
        ),),),
      onTap: (){
         Navigator.of(context).pushNamed('deldetails');
      },
    );
  }
}

