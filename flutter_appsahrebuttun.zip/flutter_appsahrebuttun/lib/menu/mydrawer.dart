import 'package:flutter/material.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/cat.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/homes.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/listslide.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/hp.dart';

class  mydrawer extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Drawer(
      child: ListView(
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountEmail: Text("fatema.mams@gmail.com"),
            accountName: Text("firat.edu.tr"),
            currentAccountPicture: CircleAvatar(
                child: Icon(Icons.person, color: Colors.black87,)
            ),
            decoration: BoxDecoration(
              color: Colors.green.shade500,
            ),
          ),
        Container( child: FlatButton
          (onPressed: ()=>Navigator.pop(context),child: Text('Close', style: TextStyle(fontWeight: FontWeight.bold),),
        ),),
    Divider(
    color: Colors.black.withOpacity(0.999999),
    height: 2
      ,),
          ListTile(
            title: Text("AnaSayfa",
                style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            leading: Icon(Icons.home),
            trailing: Icon(Icons.arrow_right),
            selected: true,
            onTap: () {
              Navigator.of(context).pushNamed('homes');
            },
          ),
          ListTile(
            title: Text("Takvim", style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            leading: Icon(Icons.calendar_today),
            trailing: Icon(Icons.arrow_right),
            selected: true,
            onTap: () {
              Navigator.of(context).pushNamed("hp");
            },
          ),
          ListTile(
            title: Text("giriş", style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            leading: Icon(Icons.add_to_home_screen,),
            trailing: Icon(Icons.arrow_right),
            selected: true,
            onTap: () {
              Navigator.of(context).pushNamed('listslide');
            },
          ),
          ListTile(
            title: Text("Markalar", style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            leading: Icon(Icons.copyright,),
            trailing: Icon(Icons.arrow_right),
            subtitle: Text(' '),
            selected: true,

            onTap: () {
              Navigator.of(context).pushNamed('cat');
            },),
          ListTile(
            title: Text("Paylaş", style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            leading: Icon(Icons.share),
            trailing: Icon(Icons.arrow_right),
            selected: true,
            onTap: () {Navigator.of(context).pushNamed('MyAppshare');},
          ),
          ListTile(
            title: Text("kategoriler", style: TextStyle(color: Colors.black,
                fontStyle: (FontStyle.italic),
                fontSize: 20)),
            selected: true,
            leading: Icon(Icons.category),
            trailing: Icon(Icons.arrow_right),
            onTap: () {Navigator.of(context).pushNamed('kategoriler');},
          )

        ],


      ),

    );

  }

}
