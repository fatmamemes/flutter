
import 'package:flutter_appsahrebuttun/Sayfalar/deldetails.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/dell.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/homes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/kategoriler.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/test.dart';
import 'package:flutter_appsahrebuttun/menu/mydrawer.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/cat.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/listslide.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/hp.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'dart:async';
import 'package:flutter_appsahrebuttun/Sayfalar/kategoriler.dart';
import 'menu/share.dart';
void main()=>runApp(Myapp());  //Bir MaterialApp() döndürür.
class Myapp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    const textStyleBold = const TextStyle(fontWeight: FontWeight.bold);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "home",
      home:homes(),
      routes: {
          'cat': (context) {
            return cat();},
          'homes': (context) { 
            return homes();},
          "dell":(context) {
            return dell();},
          'deldetails':(context){
            return deldetails();},
       'listslide':(context){
            return listslide();},
       'hp':(context) {
         return ListWheelScroll();},
       'MyAppshare':(context){
            return MyAppshare();},
          'kategoriler':(context){
            return kategoriler();
       }
        },

  );


  }
}










