import 'package:flutter/material.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/dell.dart';
import 'package:flutter_appsahrebuttun/menu/mydrawer.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/cat.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/hp.dart';
import 'package:carousel_pro/carousel_pro.dart';
class homes extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return homestate();
  }}
class homestate extends State<homes>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(title: Text("Home"),
        backgroundColor: Colors.green,
        // leading: IconButton(icon:Icon(Icons.search),onPressed: (){}),
        brightness: Brightness.light,),
      drawer: mydrawer(),
      body: (ListView(children: <Widget>[
        Container(
            height: 400,
            width: double.infinity,
            child: Carousel(
              images: [
                AssetImage('images/shopp.jpg'),
                AssetImage('images/home.jpg'),],
              dotBgColor: Colors.green.withOpacity(0.7),
              dotIncreasedColor: Colors.green.shade900,
            )
          //START CAT
        ),
        Container(padding: EdgeInsets.all(8),
          child: Text('sepetim',
            style: TextStyle(fontSize: 25, color: Colors.black,fontWeight:FontWeight.bold),),
        ),
        Container(
          height: 150,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: <Widget>[Container
              (height: 100,
                width: 100,
                child: ListTile(title: Image.asset(
                  'images/shop.png', height: 80, width: 80,),
                    subtitle: Container
                      (child: Text("laptop" ,  style:  TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.start ,),)

                )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("Ayakkabı&Çanta", textAlign: TextAlign.start,),)
                  )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("Elektronik", textAlign: TextAlign.start,),)
                  )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("Süpermarket", textAlign: TextAlign.start,),)
                  )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("Erkek", textAlign: TextAlign.start,),)
                  )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("kadın ", textAlign: TextAlign.start,),)
                  )),
              Container
                (height: 100,
                  width: 100,
                  child: ListTile(title: Image.asset(
                    'images/shop.png', height: 80, width: 80,),
                      subtitle: Container
                        (
                        child: Text("çocuk", textAlign: TextAlign.start,),)
                  )),
            ],
          ),
        ),
//END CAT

        Container(
          height: 700,
          child: GridView(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2),
            children: <Widget>[ InkWell (child: GridTile(child: Image.asset('images/mac.jpg'),
              footer: Container(
                height: 25,
                child: Text('mac2020',
                  style: TextStyle(color: Colors.black, fontSize: 25),
                  textAlign: TextAlign.center,),
                color: Colors.lightBlueAccent.withOpacity(0.9),
              ),
            ), onTap: () {},),
              InkWell (child: GridTile(child: Image.asset('images/mac.jpg'),
                footer: Container(
                  height: 25,
                  child: Text('mac2020',
                    style: TextStyle(color: Colors.black, fontSize: 25),
                    textAlign: TextAlign.center,),
                  color: Colors.lightBlueAccent.withOpacity(0.9),),), onTap:() {},),

              InkWell(child:GridTile(child: Image.asset('images/mac.jpg'),
                footer: Container(
                  height: 25,
                  child: Text('mac2020',
                    style: TextStyle(color: Colors.black, fontSize: 25),
                    textAlign: TextAlign.center,)
                  ,
                  color: Colors.lightBlueAccent.withOpacity(0.9),
                ),
              ),
                onTap: () {},),

              InkWell(child: GridTile(child: Image.asset('images/mac.jpg'),
                footer: Container(
                  height: 25,
                  child: Text('mac2020',
                    style: TextStyle(color: Colors.black, fontSize: 25),
                    textAlign: TextAlign.center,)
                  ,
                  color: Colors.lightBlueAccent.withOpacity(0.9),
                ),
              ),onTap: () {},),
              InkWell(child: GridTile(child: Image.asset('images/mac.jpg'),
                footer: Container(
                  height: 25,
                  child: Text('mac2020',
                    style: TextStyle(color: Colors.black, fontSize: 25),
                    textAlign: TextAlign.center,),
                  color: Colors.lightBlueAccent.withOpacity(0.9),
                ),
              ),
                onTap: () {},)
            ],),),
      ],)
      ),
    );
  }
}
