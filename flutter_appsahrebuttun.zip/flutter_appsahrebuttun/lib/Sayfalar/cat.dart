import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_appsahrebuttun/menu/mydrawer.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/dell.dart';
class cat extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
  return categori();
  }
}
class categori extends  State<cat> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
   return Scaffold(
     appBar: AppBar(title: Text('categori'),
     ),
     drawer: mydrawer(),
     body :
     GridView
       ( gridDelegate: SliverGridDelegateWithFixedCrossAxisCount( crossAxisCount: 2),
         children: <Widget>[
           InkWell ( child: Card(child: Column (
         children: <Widget>[ Expanded( child: Image.asset( 'images/dell.jpg',fit: BoxFit.cover,)
     ,),
          Container(child: Text('  dell',
             style: TextStyle(color: Colors.black, fontSize: 20),
             textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
       ],
     ),
    ), onTap: (){
           Navigator.of(context).pushNamed("dell");
         },),
          InkWell (  child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/hp.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  HP  2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ), onTap: (){  },),
         InkWell ( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/hw.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  HUAWI',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ), onTap: (){},),
        InkWell( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/acer.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  ACER 2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ), onTap: (){},),
          InkWell ( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/lenovo.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  LENOVO 2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),), onTap: (){},),
          InkWell ( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/asus.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  ASUS 2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ), onTap: (){},),
          InkWell( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/apple.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  APPLE 2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ),
            onTap: (){},
          ),
           InkWell ( child: Card(child: Column (
             children: <Widget>[ Expanded( child: Image.asset( 'images/msi.jpg',fit: BoxFit.cover,)
               ,),
               Container(child: Text('  MSI 2020',
                 style: TextStyle(color: Colors.black, fontSize: 20),
                 textAlign: TextAlign.center,), color: Colors.blueGrey.withOpacity(0.5),),
             ],
           ),
           ), onTap: (){},),
    ],
    ),
   );
  }
}