import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class deldetails extends StatefulWidget {
  @override
  _deldetailsState createState() => _deldetailsState();
}

class _deldetailsState extends State<deldetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:  Text ('ÖZELLIKLER'),
      ),
      body:ListView(
        children: < Widget>[
          Container(
            height: 200,
            child: GridTile(child: Image.asset( 'images/mlap.jpg'),
              footer: Container(height: 50,color: Colors.indigoAccent.withOpacity(0.3),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Container(padding: EdgeInsets.all(10),
                  child:Text(' dell 2020',
                    style: TextStyle(color: Colors.black, fontSize: 20,fontWeight: FontWeight.w700),
                    textAlign: TextAlign.center, )
                    , color: Colors.cyan.withOpacity(0.3), ),
                )
              ],
            ),),
            ),
          ), //end header page
          //start column specification
      Container( width: MediaQuery.of(context).size.width
      ,padding:  EdgeInsets.all(10), child: Text('Özelliler',style: TextStyle(fontWeight: FontWeight.w900,color: Colors.blue),
            textAlign: TextAlign.center,),
          ),
             Column(children: <Widget>[
               Container(
                 height: 30,
                 child: Row(
                   children:<Widget> [
                   Text( ' bilgisayar marka:',  style: TextStyle(color:Colors.indigoAccent,fontWeight: FontWeight.w500,fontSize: 20)  ,
                 ),

               Text( 'dell 2020',style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w500,fontSize: 20)
                 ,),

                   ],
                 ),
               )
             ],
             ),
     Column(  crossAxisAlignment:CrossAxisAlignment.start, children: <Widget>[
       Container(
         height: 30,
         color: Colors.lightBlueAccent.withOpacity(0.2),
         child: RichText( text: TextSpan( style:  TextStyle(fontSize: 20),
             children: <TextSpan>[
            TextSpan( text: ' Screen Size:',  style: TextStyle(color:Colors.indigoAccent,fontWeight: FontWeight.w500,),
           ),
            TextSpan(  text:'13 inch ',style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w500,)
           ),
         ]
         ),
         ),
         //end column specification

     ),

        ],
      ),
          Column(children: <Widget>[
            Container(
              height: 30,
              child: Row(
                children:<Widget> [
                  Text( ' bilgisayar marka:',  style: TextStyle(color:Colors.indigoAccent,fontWeight: FontWeight.w500,fontSize: 20)  ,
                  ),

                  Text( 'dell 2020',style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w500,fontSize: 20)
                    ,),

                ],
              ),
            )
          ],
          ),
          Column(  crossAxisAlignment:CrossAxisAlignment.start, children: <Widget>[
            Container(
              height: 30,
              color: Colors.lightBlueAccent.withOpacity(0.2),
              child: RichText(  text: TextSpan(  style:  TextStyle(fontSize: 20) ,children: <TextSpan>[
                TextSpan( text: ' Screen Size:',  style: TextStyle(color:Colors.indigoAccent,fontWeight: FontWeight.w500,),
                ),
                TextSpan(  text:'13 inch ',style: TextStyle(color:Colors.blueGrey,fontWeight: FontWeight.w500,)
                ),
              ]
              ),
              ),
              //end column specification

            ),

          ],
          ),
]
      )
    );


  }
}
