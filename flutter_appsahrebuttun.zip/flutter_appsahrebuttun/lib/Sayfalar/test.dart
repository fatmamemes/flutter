import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart ' as http;
import 'dart:convert' ;
import 'package:flutter_appsahrebuttun/Sayfalar/homes.dart';
 class test extends StatefulWidget {
   @override

   _testState createState() => _testState();


 }
 // ignore: camel_case_types
 class _testState extends State<test> {
   Future getData() async{
     var url=" https://jsonplaceholder.typicode.com/posts";
     var response =await http.get(url);
     var  responsebody= jsonDecode(response.body);
      return  responsebody;
   }
   @override
   Widget build(BuildContext context) {
     return Container(
       child:Scaffold(
         appBar: AppBar(
           title: Text('test'),
         ),
         body:  FutureBuilder (
           future: getData(),
           builder: ( BuildContext context, AsyncSnapshot snapshot) {
             if (snapshot.hasData) {
               return ListView.builder(
                 // ignore: missing_return
                 itemCount:  snapshot.data.length , itemBuilder:(context, i) {
                 Container(child: Text(snapshot.data[i]['body']
                 ),
                 );
               },
               );
             };

               return CircularProgressIndicator();
           },
         ),
         ),
     );
   }
 }
