import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/homes.dart';
import 'package:flutter_appsahrebuttun/menu/mydrawer.dart';
import 'package:flutter_appsahrebuttun/menu/dellist.dart';

 class dell extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return delstate();
  }
 }
  class delstate extends State<dell>{
    var dellist=[
      {
      'marka':'dell2021',
        'screenSize':' 13 inch',
      'storage':'2tb',
      ' process':'intel core i7',
      'RAM':' 16GB',
        'price':'3,000 dolar',
    },
      {
        'marka':'dell2021','screenSize':' 13 inch',
        'storage':'2tb',
        ' process':'intel core i7',
        'RAM':' 16GB','price':'2,000 dolar',
      },
      {
        'marka':'dell2021','screenSize':' 10 inch',
        'storage':'2tb',
        ' process':'intel core i7',
        'RAM':' 8GB','price':'1,000 dolar',
      },
      {
        'marka':'dell2021','screenSize':' 10 inch',
        'storage':'2tb',
        ' process':'intel core i7',
        'RAM':' 8GB','price':'1,000 dolar',
      },
      {
        'marka':'dell2021','screenSize':' 10 inch',
        'storage':'2tb',
        ' process':'intel core i7',
        'RAM':' 8GB','price':'1,000 dolar',
      },

    ];
  @override
  Widget build(BuildContext context) {

   return Scaffold(
     appBar: AppBar(
       title: Text('dell'),centerTitle: true,
     ),
     body: ListView.builder(itemCount:dellist.length
     ,itemBuilder: (context,i){
    return  Dellist( marka:dellist[i]['marka'], screenSize :dellist[i]['screenSize'],
        storage:dellist[i]['storage'],price:dellist[i]['price']
        ,RAM:dellist[i]['RAM']);
    },
    )
   );
  }
 }

