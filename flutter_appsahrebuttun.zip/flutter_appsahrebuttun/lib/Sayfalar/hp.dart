import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_appsahrebuttun/Sayfalar/homes.dart';
import 'package:flutter_appsahrebuttun/menu/mydrawer.dart';


class ListWheelScroll extends StatefulWidget{

  @override
  _ListWheelScrollState createState() => _ListWheelScrollState();

}


class _ListWheelScrollState extends State<ListWheelScroll> {

  List<String>listMonths;
  List<int>days;
  int selectedmonth = 1;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    listMonths = List();
    days = List();

    getMonths();
    getDays();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("TAKVIM"), backgroundColor: Colors.green,),

      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,

                color: Colors.grey,

                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Container(
                    color: Colors.white,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [

                        Container(
                          width: 50,
                          height: 100,
                          child: ListWheelScrollView.useDelegate(

                            childDelegate: ListWheelChildBuilderDelegate(
                                childCount: days.length,
                                builder: (BuildContext context, int index) {
                                  if (index < 0 || index > days.length) {
                                    return null;
                                  }
                                  return Container(
                                    decoration: BoxDecoration(
                                        border: Border(
                                          top: BorderSide(
                                              color: Colors.green, width: 1),

                                        )
                                    ),
                                    child: ListTile(

                                      title: Text(days[index].toString(),
                                          style: TextStyle(fontSize: 20)),

                                    ),
                                  );
                                }),
                            useMagnifier: true,
                            magnification: 1.2,
                            diameterRatio: 3,
                            itemExtent: 50,
                            onSelectedItemChanged: (index) {

                            },
                            physics: FixedExtentScrollPhysics(),

                          ),
                        ),
                        Container(
                          width: 100,
                          height: 180,
                          child: ListWheelScrollView.useDelegate(
                            childDelegate: ListWheelChildBuilderDelegate(
                                childCount: listMonths.length,
                                builder: (BuildContext context, int index) {
                                  if (index < 0 || index > listMonths.length) {
                                    return null;
                                  }
                                  return Container(
                                    decoration: BoxDecoration(
                                        border: Border(
                                          top: BorderSide(
                                              color: Colors.green, width: 1),

                                        )
                                    ),
                                    child: ListTile(

                                      title: Text(listMonths[index],
                                          style: TextStyle(fontSize: 20)),

                                    ),
                                  );
                                }),

                            useMagnifier: true,
                            magnification: 1.2,
                            diameterRatio: 6,
                            itemExtent: 50,
                            onSelectedItemChanged: (index) {
                              setState(() {
                                selectedmonth = index;
                                getDays();
                              });
                            },
                            physics: FixedExtentScrollPhysics(),

                          ),
                        ),
                        Container(
                          width: 100,
                          height: 180,
                          child: ListWheelScrollView(
                            useMagnifier: true,
                            magnification: 1.2,
                            diameterRatio: 2,
                            itemExtent: 50,
                            onSelectedItemChanged: (index) {

                            },
                            physics: FixedExtentScrollPhysics(),
                            children: [

                              getWeekDay("2020"),
                              getWeekDay("2021"),
                              getWeekDay("2022"),
                              getWeekDay("2023"),
                              getWeekDay("2024"),
                              getWeekDay("2025"),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,

                color: Colors.grey,

                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Container(
                    color: Colors.white,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text("Day of Week",style: TextStyle(color: Colors.green,fontWeight: FontWeight.bold,fontSize: 20),),
                        Container(
                          width: 200,
                          height: 180,
                          child: ListWheelScrollView(
                            useMagnifier: true,
                            magnification: 1.2,
                            diameterRatio: 3,
                            itemExtent: 50,
                                perspective: 0.0000000001,
                            squeeze: 0.5,
                              onSelectedItemChanged: (index){

                            },
                            physics: FixedExtentScrollPhysics(),
                            children:  [

                              getWeekDay("Pazartesi"),
                              getWeekDay("Salı"),
                              getWeekDay("Çarşmba"),
                              getWeekDay("Perşembe"),
                              getWeekDay("Cuma"),
                              getWeekDay("Cumartesi"),
                              getWeekDay("Pazar")
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),


          ],
        ),


      ),
    );
  }

  getWeekDay(day)
  {
    return Container(
      decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: Colors.green,width: 1),

          )
      ),
      child: ListTile(


        title: Text(day,textAlign: TextAlign.center,style: TextStyle(fontSize: 20),),

      ),
    );
  }

  getDays()
  {

    days.clear();
    switch(selectedmonth)
    {
      case 0:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 1:
        for(int k=0;k<28;k++)
          days.add(k+1);
        break;
      case 2:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 3:
        for(int k=0;k<30;k++)
          days.add(k+1);
        break;
      case 4:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 5:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 6:
        for(int k=0;k<30;k++)
          days.add(k+1);
        break;
      case 7:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 8:
        for(int k=0;k<30;k++)
          days.add(k+1);
        break;
      case 9:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
      case 10:
        for(int k=0;k<30;k++)
          days.add(k+1);
        break;
      case 11:
        for(int k=0;k<31;k++)
          days.add(k+1);
        break;
    }

    return days;
  }

  getMonths()
  {
    listMonths.add("Jan");
    listMonths.add("Feb");
    listMonths.add("Mar");
    listMonths.add("Apr");
    listMonths.add("May");
    listMonths.add("Jun");
    listMonths.add("July");
    listMonths.add("Aug");
    listMonths.add("Sept");
    listMonths.add("Oct");
    listMonths.add("Nov");
    listMonths.add("Dec");
  }

}
class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final FixedExtentScrollController _controller = FixedExtentScrollController();
  List<Widget> listtiles = [
    ListTile(
      leading: Icon(Icons.portrait),
      title: Text("Portrait"),
      subtitle: Text("Beautiful View..!"),
      trailing: Icon(Icons.arrow_forward_ios),
    ),
    ListTile(
      leading: Icon(Icons.landscape),
      title: Text("LandScape"),
      subtitle: Text("Beautiful View..!"),
      trailing: Icon(Icons.remove),
    ),
    ListTile(
      leading: Icon(Icons.map),
      title: Text("Map"),
      subtitle: Text("Map View..!"),
      trailing: Icon(Icons.wb_sunny),
    ),

    ListTile(
      leading: Icon(Icons.event),
      title: Text("Add data"),
      subtitle: Text("Data View..!"),
      trailing: Icon(Icons.add),
    ),
    ListTile(
      leading: Icon(Icons.landscape),
      title: Text("LandScape"),
      subtitle: Text("Beautiful View..!"),
      trailing: Icon(Icons.wb_sunny),
    ),
    ListTile(
      leading: Icon(Icons.email),
      title: Text("Email"),
      subtitle: Text("Check Email..!"),
      trailing: Icon(Icons.arrow_forward),
    ),
    ListTile(
      leading: Icon(Icons.games),
      title: Text("Games"),
      subtitle: Text("Play Games..!"),
      trailing: Icon(Icons.zoom_out_map),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("ListView ScrollView Wheel"),
        ),
        body: Center(
          child: ListWheelScrollView(
            controller: _controller,
            itemExtent: 80,
            magnification: 1.2,
            useMagnifier: true,
            physics: FixedExtentScrollPhysics(),
            children: listtiles, //List of widgets
          ),
        ));

  }


}














